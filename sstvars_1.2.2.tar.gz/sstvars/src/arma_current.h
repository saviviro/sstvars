#ifndef SSTVARS_ARMA_CURRENT_H
#define SSTVARS_ARMA_CURRENT_H

#define ARMA_USE_CURRENT
#include <RcppArmadillo.h>

#endif // SSTVARS_ARMA_CURRENT_H
